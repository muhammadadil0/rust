

  #![allow(dead_code)] // it must be write on the first line of the file

 fn greet(){
    
    println!("Hello I am Adil");
  }
  
  fn add(a:u32 ,b:u32){
    println!("a and b sum is {} :  ", a + b);
    
  }
  
  fn sum(a:i32,b:i32) ->i32{
       a + b
  }

  fn change(  mut x:  i32){
     x = 10;
     
     println!(" value of  x is : {}",x);
  }
  
  
  fn change_with_reference( x :&mut i32){
    *x = 50;
  }

  // # [ allow(unused_variables)]
  
  fn take_ownership(s:String){
    
    println!("s value is : {}",s);
  }
  
  fn give_owner_ship()->Vec<i32>{
    
    vec![1,2,3]
  }
  
  
  
  fn take_and_give_ownership(mut vec:Vec<i32>)->Vec<i32>{
    vec.push(10);
    vec
    
  }
  
   fn borrow(s:&String){
    println!("s : {}",s);
  }
  
  fn mutable_borrow(s:&mut String){
    *s = String::from("Azeem khattak");
  }
  
  
  fn take_ownerships_borrowing(vec:&Vec<i32>){
    println!("vec value is : {:?}",vec);
  }
  
fn main() {
  
  //  -----------------variable-------------------------
  
     let adil : i32 = 4;
     println!("value of adil is : {}", adil);
     
     let mut number = 4;
     
     number = 5;
     println!("value of number is : {}",number);
     
    println!("Hello, World!");
    
    //---------------------- constant -------------------------
    
    const ADIL:f32 = 3.2;
        
    println!("adil is : {}",ADIL);

    // ----------------Primitive Data type ------------------
    
    
    
    let a:i32 = 4;  // store negative and positive value i32,i64
    
    let b:u32 = 9; // store only positive value u32,u65
    
    let c : f32 = 3.2; // store decimal value f32,f64
    
    let charac : char = 'A'; // store character value 
    
    let boolean : bool = true; // store true and false
    
    let string_value : &str = "Adil";
    
    let string_another_type = String::from("Muhammad  Adil");
    
    
println!(
          "a is : {}
b is : {}
c is : {}
charac is : {} 
boolean is : {} 
string_value : {}
string_another_type : {}",
    a,
    b,
    c,
    charac,
    boolean,
    string_value,
    string_another_type
);
    
    
  // ---------------Compound Data Type-----------------
  
  let person : (&str, u32, f32) = ("Adil",22,3.2);
  println!("Name is {} year is : {} grade is : {}",person.0, person.1, person.2);
  
  let person: (String, u32, f32) = ("Adil".to_string(),22,3.2);
  println!("Name is {} year is : {} grade is : {}",person.0, person.1, person.2);
  
  let person : (String, u32,f32) = (String::from("adil"),22,3.2);
  println!("Name is {} year is : {} grade is : {}",person.0, person.1, person.2);
  
  
  
  let numbers = [1,2,3,4,5];
  println!("Number in index 0 is : {}", numbers[0]);
  
  
   // ---------------Function And Code Block ---------------- 
  
 
  // function without parameter
  
  greet();
  
  // function with parameter
  
  add(5,3);
  
  // function with return value
  
  
  let result = sum(5,10);
  println!("Result is : {}",result);
  
  
  // -------------mutability in function -------------
  
  let value :i32 =10;
  change(value);
  
  
  
  let mut value :i32 = 10;
  println!("value is : {}",value);
  change_with_reference(&mut value);
  println!("value is : {}",value);
  
  
  
  
  // condition if else
  
  
  let age = 18;
  
  if age>18{
    println!("You are above 18");
    
    
  }
  else if age ==18{
    println!("you are 18");
  }
  else {
    println!("You are under 18");
  }
  
  
  
  match age {
    17 => println!("17"),
    18 => println!("18"),
    _=>println!("nothing"),
    
  }
  
  // ---- for loop with ranges -------------
  
  
  
  for i in 0..5 {
    
    print!(" {}",i);
    
    //  every value in new line 
    
    //  println!("i is : {}", i);
    
  }
  println!("");
  
  
  // for loop inclusive 5 also we used assignment = 
  
  for i in 0..=5 {
    println!("i is  : {} ",i);
  }
  
  // reverse loop
  let num = 5;
  for i in  (0..=num).rev(){
    
    println!("i is : {}",i);
  }
  
  // multi line comment
  
  /*
  
  you can write anything between this 
 
  */
  
  // debug printing 
  
  let nums = [1,2,4];
  println!("num is {:?}",nums);  // num is [1, 2, 4]
 println!(" num is {:#?}", nums);   /* 
 
 num is [
    1,
    2,
    4,
]
created 15 hours ago

*/

  
  // ----------variable naming convention-------
  
  // variable name should be snake case
  
  let student_name : &str = "Adil";
  println!("Student name is : {}", student_name);
 
  // this one is not a good convention in rust 
  let Student_Name = "Adil";
  println!("Student name is : {}", Student_Name);
  
  
  
  // -------------- compiler directive --------------
  
   /* for now we are not using this variable 
   so  we tell compiler to allow unused variable 
   
   for that we write on main above this line 
   
   #[ allow (unused_variables)  ]
   */
   
   
   
   // f is unused variable 
  let f = 5;
  
  
  
  
  /* to stop warning you can used this function 
  #![ allow(dead_code)] 
    and it must be write on the first line of the file
  */
  
  
  // ----------- common error types ---------- 
  
  /* E0384 immutable variable 
     E0308 type mismatch 
     E0425 variable not found 
     E0596 mutable borrow issue
  */
  
  //  -----Operators in Rust -------
  
  //  Arithmetic
  
  //  +  -  *  /  %
  
  //  Comparison
  
  //   ==  !=  >  <  >=  <=
  
  //     Logical

  //     &&  ||  !
   
  //   Assignment

  //  =  +=  -=  *=  /=
  
  
 //     Bitwise
  
 //  &  |  ^  <<  >>

  
  
  
  
  let marks = 90;
  
  let grade = match marks {
    90 => "A",
    _=> "B",
  };
  
  println!("grade is : {}",grade);
  
  
  
  // ownership 
  
  
  // each value has a variabel that is owner 
  // each value has one owner 
  
  let s1 :String = String::from("adil");
  let s2 = s1;
  let s3 = s2.clone();
  println!("s2 is : {}", s3);
  
  
  // Function and owner ownership
  
  
  let s1 :String = String::from("kaif");
  
  take_ownership(s1);
  
  // println!("s1 is : {}",s1);
  
  let s2 = give_owner_ship();
  
  println!("s2 is : {:?}",s2);
  
  let  vec:Vec<i32> = vec![1,2,3];
  let take_owner = take_and_give_ownership(vec);
  
  println!("take_owner is : {:?}",take_owner);
  
  // borrowing 
  
  let value : String = String::from("adil");
  
  borrow(&value);
  
  println!("value is : {}",value);
 
  
  
  // mutable reference or borrowing 
  
  let mut name: String = String::from("azeem");
  
   mutable_borrow(&mut name);
   
  
  
  
  let mut vec1 : Vec<i32> = vec![1,2,4];
  
  let ref1 = & vec1;
  let ref2 = & vec1;
  
  println!("ref1 is {:?} and ref2 is {:?}",ref1,ref2);
  
  
  let vec:Vec<i32> = vec![1,2,3];
  let ref1 = &vec;
  take_ownerships_borrowing(&ref1);
  
  
  
  
  
  
  
  
  
  
  
  
    
    
    
}